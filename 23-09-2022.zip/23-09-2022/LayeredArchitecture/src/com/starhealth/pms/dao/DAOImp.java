package com.starhealth.pms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.starhealth.pms.bean.Products;

public class DAOImp implements IproductDAO {

	Connection con = DbUtil.getCon();

	@Override
	public int addProducts(Products obj) {
		int count = 0;

		try {
			String insertQuery = "insert into products(sno, proName, cost) values(?,?,?)";

			PreparedStatement pstmt = con.prepareStatement(insertQuery);

			pstmt.setInt(1, obj.getSno());
			pstmt.setString(2, obj.getProName());
			pstmt.setDouble(3, obj.getCost());

			count = pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return count;

	}

	@Override
	public int updateProducts(Products obj) {

		int count = 0;
		try {

			String updateQuery = "update products set proName =? , cost = ? where sno = ?";
			PreparedStatement pstmt = con.prepareStatement(updateQuery);

			pstmt.setString(1, obj.getProName());
			pstmt.setInt(2, obj.getCost());
			pstmt.setInt(3, obj.getSno());

			count = pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return count;
	}

	@Override
	public int deleteProducts(int sno) {
		String deleteQuery = "delete from products where sno = ?";

		PreparedStatement pstmt;
		int deleteCount = 0;
		try {
			pstmt = con.prepareStatement(deleteQuery);

			pstmt.setInt(1, sno);

			deleteCount = pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return deleteCount;
	}

	@Override
	public Products selectProduct(int sno) {
		String selectQuery = "select * from products where sno = ?";

		PreparedStatement pstmt;

		Products obj = new Products();

		try {
			pstmt = con.prepareStatement(selectQuery);

			pstmt.setInt(1, sno);

			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {

				obj.setSno(rs.getInt("sno"));
				obj.setProName(rs.getString("proName"));
				obj.setCost(rs.getInt("cost"));

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return obj;

	}

	@Override
	public List<Products> selectAllProducts() {
		String selectQuery = "select * from products";

		PreparedStatement pstmt;

		List<Products> list = new ArrayList<Products>();
		
		try {
			pstmt = con.prepareStatement(selectQuery);

			ResultSet rs = pstmt.executeQuery();

			

			while (rs.next()) {

				Products obj = new Products();
				
				obj.setSno(rs.getInt("sno"));
				obj.setProName(rs.getString("proName"));
				obj.setCost(rs.getInt("cost"));
				

				list.add(obj);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		return list;
	}
	}


