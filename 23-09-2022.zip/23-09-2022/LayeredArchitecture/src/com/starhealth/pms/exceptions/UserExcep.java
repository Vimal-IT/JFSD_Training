package com.starhealth.pms.exceptions;

import com.starhealth.pms.bean.Products;

public class UserExcep extends Exception{
	
	public UserExcep(String s) {
		
		super(s);
	}
	

}
