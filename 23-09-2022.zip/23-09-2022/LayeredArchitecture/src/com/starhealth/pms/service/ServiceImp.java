package com.starhealth.pms.service;

import java.util.List;

import com.starhealth.pms.bean.Products;
import com.starhealth.pms.dao.DAOImp;
import com.starhealth.pms.dao.IproductDAO;

public class ServiceImp implements IproService {
	
	IproductDAO oj = new DAOImp();

	@Override
	public int addProducts(Products obj) {
		return oj.addProducts(obj);
	}

	@Override
	public int updateProducts(Products obj) {
		return oj.updateProducts(obj);
	}

	@Override
	public int deleteProducts(int sno) {
		return oj.deleteProducts(sno);
	}

	@Override
	public Products selectProduct(int sno) {
		return oj.selectProduct(sno);
	}

	@Override
	public List<Products> selectAllProducts() {
		return oj.selectAllProducts();
	}
	

	public static boolean validateInputs(Products obj) {

		boolean isValid = false;
	
	if (obj.getSno() < 99 && obj.getProName().length() > 3 && obj.getCost() > 100) {

		isValid = true;
	}
	
	return isValid;

}


}
